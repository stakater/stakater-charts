{{/*
Name for the gateway's cluster scoped RBAC objects.

ClusterRoles and ClusterRoleBindings are not namespaced, so the release
namespace has to be part of the name. Without it two installs in different
namespaces collide on one object and the second install rebinds the first
install's ServiceAccount.
*/}}
{{- define "reloader-enterprise.gateway.clusterRoleName" -}}
{{- printf "%s-%s-gateway" .Release.Namespace .Release.Name | trunc 253 | trimSuffix "-" -}}
{{- end -}}

{{/*
ServiceAccount the gateway subchart attaches to its pod. Mirrors the subchart's
own default so the binding always targets the SA that actually exists.
*/}}
{{- define "reloader-enterprise.gateway.serviceAccountName" -}}
{{- default (include "reloader-enterprise.gateway.applicationName" .) .Values.gateway.rbac.serviceAccount.name -}}
{{- end -}}

{{/*
Gateway application name, matching the subchart's `default .Chart.Name .Values.applicationName`.
*/}}
{{- define "reloader-enterprise.gateway.applicationName" -}}
{{- default "application" .Values.gateway.applicationName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels for objects the umbrella chart owns.
*/}}
{{- define "reloader-enterprise.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ .Chart.Name }}
{{- end -}}
