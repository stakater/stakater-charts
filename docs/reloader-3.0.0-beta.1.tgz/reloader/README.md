# Reloader Helm Chart

If you have configured helm on your cluster, you can add Reloader to helm from our public chart repository and deploy it via helm using below-mentioned commands. Follow the [Helm2 to Helm3 guide](../../../../docs/Helm2-to-Helm3.md), in case you have trouble migrating Reloader from Helm2 to Helm3.

## Installation

> **Reloader v2 is currently a prerelease.** The commands below resolve to the
> latest *stable* chart, which is still Reloader v1. To install the v2 beta you
> must opt in explicitly, because Helm skips prerelease versions by default:
>
> ```bash
> # --devel picks up the newest prerelease; add --version to pin a specific beta
> helm install {{RELEASE_NAME}} stakater/reloader --devel
> ```

```bash
# Add stakater helm repoository
helm repo add stakater https://stakater.github.io/stakater-charts

helm repo update

helm install stakater/reloader # For helm3 add --generate-name flag or set the release name

helm install {{RELEASE_NAME}} stakater/reloader -n {{NAMESPACE}} --set reloader.watchGlobally=false # By default, Reloader watches in all namespaces. To watch in single namespace, set watchGlobally=false

helm install stakater/reloader --set reloader.watchGlobally=false --namespace test --generate-name # Install Reloader in `test` namespace which will only watch `Deployments`, `Daemonsets` `Statefulsets` and `Rollouts` in `test` namespace.

helm install stakater/reloader --set reloader.ignoreJobs=true --set reloader.ignoreCronJobs=true --generate-name # Install Reloader ignoring Jobs and CronJobs from reload monitoring
```

## Uninstalling

```bash
helm uninstall {{RELEASE_NAME}} -n {{NAMESPACE}}
```

## Parameters

### Global Parameters

| Parameter                 | Description                                                     | Type  | Default |
| ------------------------- | --------------------------------------------------------------- | ----- | ------- |
| `global.imagePullSecrets` | Reference to one or more secrets to be used when pulling images | array | `[]`    |

### Common Parameters

| Parameter          | Description                              | Type   | Default           |
| ------------------ | ---------------------------------------- | ------ | ----------------- |
| `nameOverride`     | replace the name of the chart            | string | `""`              |
| `fullnameOverride` | replace the generated name               | string | `""`              |
| `image`            | Set container image name, tag and policy. `image.tag` defaults to the chart `appVersion` when empty | map    | `see values.yaml` |

### Core Reloader Parameters

| Parameter                           | Description                                                                                                                                         | Type        | Default   |
| ----------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- | --------- |
| `reloader.autoReloadAll`            |                                                                                                                                                     | boolean     | `false`   |
| `reloader.isArgoRollouts`           | Enable Argo `Rollouts`. Valid value are either `true` or `false`                                                                                    | boolean     | `false`   |
| `reloader.isOpenshift`              | Enable OpenShift DeploymentConfigs. Valid value are either `true` or `false`                                                                        | boolean     | `false`   |
| `reloader.ignoreSecrets`            | To ignore secrets. Valid value are either `true` or `false`. Either `ignoreSecrets` or `ignoreConfigMaps` can be ignored, not both at the same time | boolean     | `false`   |
| `reloader.ignoreConfigMaps`         | To ignore configmaps. Valid value are either `true` or `false`                                                                                      | boolean     | `false`   |
| `reloader.ignoreJobs`               | To ignore jobs from reload monitoring. Valid value are either `true` or `false`. Translates to `--ignored-workload-types=jobs`                      | boolean     | `false`   |
| `reloader.ignoreCronJobs`           | To ignore CronJobs from reload monitoring. Valid value are either `true` or `false`. Translates to `--ignored-workload-types=cronjobs`               | boolean     | `false`   |
| `reloader.reloadOnCreate`           | Enable reload on create events. Valid value are either `true` or `false`                                                                            | boolean     | `false`   |
| `reloader.reloadOnDelete`           | Enable reload on delete events. Valid value are either `true` or `false`                                                                            | boolean     | `false`   |
| `reloader.syncAfterRestart`         | Enable sync after Reloader restarts for **Add** events, works only when reloadOnCreate is `true`. Valid value are either `true` or `false`          | boolean     | `false`   |
| `reloader.reloadStrategy`           | Strategy to trigger resource restart, set to either `default`, `env-vars` or `annotations`                                                          | enumeration | `default` |
| `reloader.ignoreNamespaces`         | List of comma separated namespaces to ignore, if multiple are provided, they are combined with the AND operator. Only honored when `reloader.watchGlobally` is `true`; in single-namespace and scoped (`reloader.namespaces`) modes the watched set is already explicit and this value is ignored. | string      | `""`      |
| `reloader.namespaceSelector`        | List of comma separated k8s label selectors for namespaces selection. The parameter only used when `reloader.watchGlobally` is `true`. See [LIST and WATCH filtering](https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/#list-and-watch-filtering) for more details on label-selector                                  | string      | `""`      |
| `reloader.resourceLabelSelector`    | List of comma separated label selectors, if multiple are provided they are combined with the AND operator                                           | string      | `""`      |
| `reloader.logFormat`                | Set type of log format. Value could be either `json` or `""`                                                                                        | string      | `""`      |
| `reloader.watchGlobally`            | Allow Reloader to watch in all namespaces (`true`) or just in a single namespace (`false`)                                                          | boolean     | `true`    |
| `reloader.namespaces`               | Explicit namespaces to watch (scoped mode). When non-empty and `reloader.watchGlobally` is `false`, Reloader watches exactly these namespaces and the chart creates a namespace-scoped Role + RoleBinding in each (no ClusterRole). The release namespace is not watched for reloads unless you list it explicitly; the chart only grants it a minimal Role for Reloader's internal meta-info ConfigMap (and leader-election in HA). Accepts either a YAML list (`["team-a","team-b"]`) or a comma-separated string (`"team-a,team-b"`).                                                 | list/string | `[]`      |
| `reloader.enableHA`                 | Enable leadership election allowing you to run multiple replicas                                                                                    | boolean     | `false`   |
| `reloader.leaderElection.id` | Name of the Lease Reloader locks on, only applied when `reloader.enableHA` is `true`. The RBAC `get`/`update` grant is pinned to this name. Empty keeps the binary default of `reloader-leader-election` | string | `""` |
| `reloader.leaderElection.leaseDuration` | Duration non-leader candidates wait before force acquiring leadership, only applied when `reloader.enableHA` is `true`. Empty keeps the client-go default of `15s`. A Go duration string, for example `30s`, and must be greater than `renewDeadline` | string | `""` |
| `reloader.leaderElection.renewDeadline` | Duration the acting leader retries refreshing leadership before giving up, only applied when `reloader.enableHA` is `true`. Empty keeps the client-go default of `10s`. A Go duration string, for example `10s` | string | `""` |
| `reloader.leaderElection.retryPeriod` | Duration clients wait between attempting acquisition and renewal of leadership, only applied when `reloader.enableHA` is `true`. Empty keeps the client-go default of `2s`. A Go duration string, for example `2s` | string | `""` |
| `reloader.enablePProf`              | Enables pprof for profiling | boolean | `false` |
| `reloader.pprofAddr` | Address to start pprof server on | string | `:6060` |
| `reloader.readOnlyRootFileSystem`   | Enforce readOnlyRootFilesystem                                                                                                                      | boolean     | `false`   |
| `reloader.legacy.rbac`              |                                                                                                                                                     | boolean     | `false`   |
| `reloader.matchLabels`              | Pod labels to match                                                                                                                                 | map         | `{}`      |
| `reloader.enableMetricsByNamespace` | Expose an additional Prometheus counter of reloads by namespace (this metric may have high cardinality in clusters with many namespaces)            | boolean     | `false`   |

### Deployment Reloader Parameters

| Parameter                                       | Description                                                                                                                                                 | Type   | Default           |
| ----------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- | ------ | ----------------- |
| `reloader.deployment.replicas`                  | Number of replicas, if you wish to run multiple replicas set `reloader.enableHA = true`. The replicas will be limited to 1 when `reloader.enableHA = false` | int    | 1                 |
| `reloader.deployment.revisionHistoryLimit`      | Limit the number of revisions retained in the revision history                                                                                              | int    | 2                 |
| `reloader.deployment.hostUsers`                 | Enable user namespace                                                                                                       | boolean    |               |
| `reloader.deployment.nodeSelector`              | Scheduling pod to a specific node based on set labels                                                                                                       | map    | `{}`              |
| `reloader.deployment.affinity`                  | Set affinity rules on pod                                                                                                                                   | map    | `{}`              |
| `reloader.deployment.securityContext`           | Set pod security context                                                                                                                                    | map    | `{}`              |
| `reloader.deployment.containerSecurityContext`  | Set container security context                                                                                                                              | map    | `{}`              |
| `reloader.deployment.tolerations`               | A list of `tolerations` to be applied to the deployment                                                                                                     | array  | `[]`              |
| `reloader.deployment.topologySpreadConstraints` | Topology spread constraints for pod assignment                                                                                                              | array  | `[]`              |
| `reloader.deployment.annotations`               | Set deployment annotations                                                                                                                                  | map    | `{}`              |
| `reloader.deployment.labels`                    | Set deployment labels, default to Stakater settings                                                                                                         | array  | `see values.yaml` |
| `reloader.deployment.env`                       | Support for extra environment variables                                                                                                                     | array  | `[]`              |
| `reloader.deployment.livenessProbe`             | Set liveness probe timeout values                                                                                                                           | map    | `{}`              |
| `reloader.deployment.readinessProbe`            | Set readiness probe timeout values                                                                                                                          | map    | `{}`              |
| `reloader.deployment.resources`                 | Set container requests and limits (e.g. CPU or memory)                                                                                                      | map    | `{}`              |
| `reloader.deployment.pod.annotations`           | Set annotations for pod                                                                                                                                     | map    | `{}`              |
| `reloader.deployment.priorityClassName`         | Set priority class for pod in cluster                                                                                                                       | string | `""`              |
| `reloader.deployment.runtimeClassName`          | Set the runtimeClassName for the pod                                                                                                                        | string | `""`              |
| `reloader.deployment.schedulerName`             | Set the schedulerName for the pod                                                                                                                           | string | `""`              |
| `reloader.deployment.volumeMounts`              | Mount volume                                                                                                                                                | array  | `[]`              |
| `reloader.deployment.volumes`                   | Add volume to a pod                                                                                                                                         | array  | `[]`              |

| `reloader.deployment.dnsConfig`                 | dns configuration for pods                                                                                                                                  | map    | `{}`              |
### Other Reloader Parameters

| Parameter                              | Description                                                     | Type    | Default |
| -------------------------------------- | --------------------------------------------------------------- | ------- | ------- |
| `reloader.service`                     | Service settings. Rendered only when non-empty. Supports `labels`, `annotations`, `port`, and the dual-stack keys `ipFamilyPolicy` (`SingleStack`, `PreferDualStack` or `RequireDualStack`) and `ipFamilies` (up to two of `IPv4`, `IPv6`) | map     | `{}`    |
| `reloader.rbac.enabled`                | Specifies whether a role based access control should be created | boolean | `true`  |
| `reloader.serviceAccount.create`       | Specifies whether a ServiceAccount should be created            | boolean | `true`  |
| `reloader.custom_annotations`          | Add custom annotations                                          | map     | `{}`    |
| `reloader.serviceMonitor.enabled`      | Enable to scrape Reloader's Prometheus metrics (legacy)         | boolean | `false` |
| `reloader.podMonitor.enabled`          | Enable to scrape Reloader's Prometheus metrics                  | boolean | `false` |
| `reloader.podDisruptionBudget.enabled` | Limit the number of pods of a replicated application            | boolean | `false` |
| `reloader.netpol.enabled`              |                                                                 | boolean | `false` |
| `reloader.volumeMounts`                | Mount volume                                                    | array   | `[]`    |
| `reloader.volumes`                     | Add volume to a pod                                             | array   | `[]`    |
| `reloader.webhookUrl`                  | Add webhook to Reloader                                         | string  | `""`    |

## ⚙️ Helm Chart Configuration Notes

### Selector Behavior
- Both `namespaceSelector` & `resourceLabelSelector` can be used together
- **Both conditions must be met** for a ConfigMap/Secret to trigger reloads
  - Example: If a ConfigMap matches `resourceLabelSelector` but not `namespaceSelector`, it will be ignored

### Important Limitations
- Only one of these resources can be ignored at a time:
  - `ignoreConfigMaps` **or** `ignoreSecrets`
  - Trying to ignore both will cause Helm template compilation errors
- The `ignoreJobs` and `ignoreCronJobs` flags can be used together or individually
  - When both are enabled, translates to `--ignored-workload-types=jobs,cronjobs`
  - When used individually, translates to `--ignored-workload-types=jobs` or `--ignored-workload-types=cronjobs`
  - These flags prevent Reloader from monitoring and reloading the specified workload types

### Special Integrations
- OpenShift (`DeploymentConfig`) and Argo Rollouts support must be **explicitly enabled**
  - Required due to potential permission restrictions on clusters

### OpenShift Considerations
- Recent OpenShift versions (tested on 4.13.3) require:
  - Users to be in a dynamically assigned UID range
  - **Solution**: Unset `runAsUser` via `reloader.deployment.securityContext.runAsUser=null`
  - Let OpenShift assign UID automatically during installation

### Core Functionality Flags

#### 🔄 `reloadOnCreate` Behavior
**When true:**
✅ New ConfigMaps/Secrets trigger rolling updates for referencing workloads

**When false:**
❌ ConfigMaps/Secrets creations have no effect on referencing workloads

#### 🗑️ `reloadOnDelete` Behavior
**When true:**
✅ Deleted ConfigMaps/Secrets trigger rolling updates for referencing workloads

**When false:**
❌ ConfigMaps/Secrets deletions have no effect on referencing workloads

#### 🔄 `syncAfterRestart` Behavior
**When true:**
✅ In HA mode, new leader reloads all tracked workloads

**When false:**
❌ Updates during leader downtime are missed
⏳ Potential 15s delay window (default `LeaseDuration`)

#### 🗳️ `enableHA` Behavior
**When true:**
✅ `--enable-ha=true` and the `POD_NAME`/`POD_NAMESPACE` env vars are rendered
✅ The `coordination.k8s.io` Lease RBAC is rendered when `reloader.rbac.enabled` is `true`. It always lands in the namespaced `-metadata-role` in the release namespace, never in the ClusterRole and never in the watched namespace Roles, and `get`/`update` are restricted to the lease the chart also names in `--leader-election-id`, so the grant and the flag cannot disagree
✅ The default pod anti-affinity is rendered unless custom affinity is configured
✅ `reloader.deployment.replicas` is honored, and any `reloader.leaderElection.*` settings are passed to the binary

**When false:**
❌ `reloader.deployment.replicas` is clamped to `1`, whatever value is set
❌ `reloader.leaderElection.*` settings are ignored

> ⚠️ **Behavior change:** earlier chart versions emitted `--enable-ha=true` whenever `reloader.deployment.replicas > 1`, even with `reloader.enableHA: false`. Every other HA component stayed gated on `enableHA` alone, so the pod rendered without `POD_NAME` and the binary exited with `POD_NAME not set, cannot run in HA mode without POD_NAME set`, leaving it in `CrashLoopBackOff`. The flag is now gated on `enableHA` alone. Raising `replicas` by itself therefore leaves HA off, consistent with the existing replica clamp. Setting `reloader.enableHA: true` is unaffected.

#### Default Settings
⚠️ All flags default to `false` (must be enabled explicitly):
- `reloadOnCreate`
- `reloadOnDelete`
- `syncAfterRestart`

### Deprecation Notice
- `serviceMonitor` will be removed in future releases in favor of `PodMonitor`

## Enterprise mode

Reloader Enterprise adds a console, gateway, and cache (dragonfly) alongside the
operator. It ships as an optional subchart gated by `enterprise.enabled`.

Enabling it requires **five** changes, because the operator image is swapped manually:

1. Turn on the subchart and set the hostname. The console and the gateway share a
   single hostname and are told apart by path: the console at `/`, the gateway at
   `global.gatewayBasePath`.

   ```yaml
   enterprise:
     enabled: true
   global:
     host: reloader.apps.example.com
     gatewayBasePath: /gateway   # default
     ingressScheme: https        # default
   ```

   > `global.host` is required when `enterprise.enabled=true`. Leaving it empty
   > renders both Ingresses with an empty `host:` and **no error**, so the release
   > installs and the console is simply unreachable.

2. Swap the operator image to the enterprise image:

   ```yaml
   image:
     repository: ghcr.io/stakater/reloader-enterprise
     tag: v1.4.22   # a Reloader release tag; add -ubi for the UBI variant
   ```

   > **Version note:** three different numbers are in play here, don't mix them up:
   > - `image.tag` above is the **enterprise operator image** tag. These mirror the
   >   Reloader release tags (`v1.4.22`, plus a `v1.4.22-ubi` variant), because the
   >   enterprise pipeline builds from a Reloader tag. A tag only exists once that
   >   pipeline has run for the release, so it can lag the OSS image.
   > - the `reloader-enterprise` **subchart** version (`0.1.3`, in `Chart.yaml`
   >   dependencies) is the Helm chart version, not an image tag.
   > - the console and gateway images have their own tags again, set under
   >   `enterprise.console.*` / `enterprise.gateway.*`.

3. Provide an image pull secret. The enterprise **operator** image is in private
   GHCR. The console and gateway images are published to `ghcr.io/stakater/public/`
   and pull anonymously, so this secret is only needed for the operator image:

   ```bash
   kubectl create secret docker-registry saap-dockerconfigjson \
     --docker-server=ghcr.io \
     --docker-username=<user> --docker-password=<token> \
     -n <release-namespace>
   ```

   ```yaml
   global:
     imagePullSecrets:
       - name: saap-dockerconfigjson
   ```

   > The subchart still names `saap-dockerconfigjson` per component by default. A
   > pull secret that does not exist is a warning, not a failure, so the public
   > console and gateway images still pull.

4. Choose the gateway tier. These values live under `gateway:` inside the
   enterprise chart, so the keys are `enterprise.gateway.*`. `enterprise.tier`
   looks right and is silently ignored.

   ```yaml
   enterprise:
     gateway:
       tier: free                  # default; caps at 3 namespaces
       namespaces: "app-a,app-b"   # required on any finite cap
   ```

   > On the free tier `namespaces` defaults to the release namespace, which holds
   > nothing worth watching, so the console looks empty until you set it. The free
   > tier also **purges** cached data and reload history for namespaces outside the
   > list. `tier: paid` needs a valid signed license ConfigMap in the release
   > namespace and the gateway refuses to start without one; it never downgrades.

5. Deeper enterprise component settings pass through under `enterprise.console.*`,
   `enterprise.gateway.*`, and `enterprise.dragonfly.*` (see the reloader-enterprise
   chart values for the full list). Values you do not override fall back to the
   subchart defaults.

When `enterprise.enabled=false` (the default) none of the enterprise components are
rendered and the operator uses the community image.

## Release Process

_Helm chart versioning_: The Reloader Helm chart is maintained in this repository. The Helm chart has its own semantic versioning. Helm charts and code releases are separate artifacts and separately versioned. Manifest making strategy relies on Kustomize. The Reloader Helm chart manages the two artifacts with these two fields:

- [`appVersion`](Chart.yaml) points to released Reloader application image version listed on the [releases page](https://github.com/stakater/Reloader/releases)
- [`version`](Chart.yaml) sets the Reloader Helm chart version

Helm chart will be released to the chart registry whenever files in `deployments/kubernetes/chart/reloader/**` change on the main branch.

### To release the Helm chart

1. Create a new branch and update the Helm chart `appVersion` and `version`, example pull-request: [PR-846](https://github.com/stakater/Reloader/pull/846)
1. Label the PR with `release/helm-chart`
1. After approval and just before squash, make sure the squash commit message represents all changes, because it will be used to autogenerate the changelog message
